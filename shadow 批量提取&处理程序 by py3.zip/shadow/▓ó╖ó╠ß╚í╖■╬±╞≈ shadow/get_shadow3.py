#!/usr/bin/env python3
# encoding: utf-8
# 2016.11.1 04: 34 by drop qq 342737268 with python3.5.2

import os
import sys
import multiprocessing


# get filename of expect.sh and filename of do-linx.sh
file_lst = os.listdir('.')
for i in file_lst:
    if i.startswith('expect') and i.endswith('.sh'):
        expect_file = i
    elif i.startswith('do') and i.endswith('.sh'):
        do_file = i


def get_shadow(ip, usr, pwd):
    global expect_file, do_file
    shadow_fn = ip + '.shadow'
    # run shell script
    if '$' not in usr:
        s = os.popen('expect {expect_file} {ip} {usr} {pwd} > {shadow_fn}'.format(
            expect_file=expect_file, ip=ip, usr=usr, pwd=pwd, shadow_fn=shadow_fn))
    else:
        with open('ip.txt', 'w') as f:
            f.write('  '.join([ip, usr, pwd]))
        s = os.popen('expect {do_file}'.format(do_file=do_file))

    # check result, if get ip.shadow file and lines > 10 then ok !
    is_ok = False
    s.read()    # wait shell script return value
    if os.path.isfile(shadow_fn):
        lines = open(shadow_fn).readlines()
        if len(lines) < 10:
            os.remove(shadow_fn)
        else:
            is_ok = True

    if is_ok == False:
        print('Error: {ip} {usr} {pwd}'.format(ip=ip, usr=usr, pwd=pwd))
        open('{ip} {usr} {pwd}.error'.format(ip=ip, usr=usr, pwd=pwd), 'w')
        return 1
        # get_shadow(ip, usr, pwd)
    print('{} shadow already got!'.format(ip))
    return 0


def boss(fn, n=1):
    '''@fn: filename of (ip, usr, pwd) text file '''
    lst = []
    with open(fn) as f:
        for line in f:
            lst.append(line.split())
    with multiprocessing.Pool(processes=n, maxtasksperchild=8) as pool:
        result = pool.starmap_async(get_shadow, lst)
        if result.get():
            pool.close()
    print('{} process starting!\n'.format(n))


if __name__ == '__main__':
    help = '''run like this:
    $python get_shadow.py ip_usr_pwd_list.txt
    Be carefule: do not use ip.txt, or you will get error result !
    \ninput Yes(y)/No(n) to Run/Exit program : '''

    # get_shadow('10.112.102.162', 'aiuap', '=KhuPzH2')

    a = input(help).strip().lower()[0]
    print(sys.argv, a)
    if a == 'y' and len(sys.argv) == 2:
        try:
            boss(sys.argv[1], 1)
        except KeyboardInterrupt:
            print('\nWhy you kill me ? I want to run! Run me! Run me! Run me!' * 100)
            sys.exit()
    else:
        print(help)
        print('Run me again!')

