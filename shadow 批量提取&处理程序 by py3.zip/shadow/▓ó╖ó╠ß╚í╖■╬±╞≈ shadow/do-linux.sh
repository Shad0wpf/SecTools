#!/usr/bin/env bash
LANG=C; export LANG

cat ip.txt|grep -Ev "^$|^#" |while read host user rootpw
do
   ./expect.sh ${host} ${user} ${rootpw} 
done
