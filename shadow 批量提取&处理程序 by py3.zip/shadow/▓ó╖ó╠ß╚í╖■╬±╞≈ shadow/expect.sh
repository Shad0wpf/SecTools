#!/usr/bin/expect -f
set host [lindex $argv 0]
set user [lindex $argv 1]
set rootpw [lindex $argv 2]
set timeout 130
spawn ssh -o StrictHostKeyChecking=no -l $user $host
expect "assword:" 
send "$rootpw\r"
expect "\\$"
send "sudo cat /etc/shadow\r"
expect "assword:" 
send "$rootpw\r"
expect "\\$"
send "exit\r"

expect eof