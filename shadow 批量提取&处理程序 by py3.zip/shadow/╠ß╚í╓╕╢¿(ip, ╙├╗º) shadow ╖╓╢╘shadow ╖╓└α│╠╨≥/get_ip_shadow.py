#!/usr/bin/env python
# encoding: utf-8

import os
import re
import sys
import time

ip_usr_set = set()

def help():
    print('[help] shell# python3 get_usr_shadow.py ip_usr.txt')
    sys.exit()


def get_usr(ext='.shadow', shadow_path='.', out_path='.'):
    '''
    @ext: str, file extension of linx shadow
    @shadow_path: str, shadow_path of shadow files
    '''
    print(sys.argv)
    assert os.path.isdir(shadow_path), 'invalid shadow file path'
    assert os.path.isdir(out_path), 'invalid output file path'
    if len(sys.argv) < 2:
        help()
    elif not os.path.isfile(sys.argv[1]):
        help()

    # ipUsr -> [[ip0, usr0], [ip1, usr1], ... [ipN, usrN]]
    ipUsr = [i.split() for i in open(sys.argv[1]).readlines()]
    wf = dict()
    n = 1
    errors = []
    for ip, usr in ipUsr:
        fn = os.path.join(shadow_path, ip + '.shadow')
        if not os.path.isfile(fn):
            errors.append(ip + ':' + usr + ':without shadow')
            continue
        stat = False
        for line in open(fn):
            if usr in line:
                wf, stat = check_write_shadow(wf, usr, ip, line)
                if stat is True:
                    if (ip, usr) in ip_usr_set:
                        ipdb.set_trace()
                    else:
                        ip_usr_set.add((ip, usr))
                    n += 1
                    break
                if (not (n & 0xff)) and stat:
                    print(n, usr, ip)
        if stat is False:
            errors.append(ip + ':' + usr + ':not found in shadow')

    fn_error = 'error_shadows_not_found.txt'
    errors = set(errors)
    with open(fn_error, 'w') as f:
        for line in errors:
            f.write(line + '\n')
            print(line)
        print('Build file : {}'.format(fn_error))
    for file in wf:
        print('Build file : {}'.format(wf[file].name))
        wf[file].close()
    print('Finished: output {} lines'.format(n))


def check_write_shadow(wf, usr, ip, line):
    items = line.split(':')
    if len(items) != 9 or usr != items[0]:
        return wf, False
    shadow_type = re.search(r'\$(\d)\$', items[1])
    if shadow_type == None:
        shadow_type = '0'
    else:
        shadow_type = shadow_type.group(1)
    if not wf.get(shadow_type, False):
        filename = 'shadow_type{}.txt'.format(shadow_type)
        wf[shadow_type] = open(filename, 'w')
    wf[shadow_type].write(ip + '  ' +  line)
    return wf, True


if __name__ == '__main__':
    # python *.py ipUsr.txt
    import ipdb
    t0 = time.time()
    get_usr(ext='.shadow', shadow_path='.', out_path='.')
    print('time used: {}s'.format(round(time.time() - t0, 2)))
