#!/usr/bin/env python3
# encoding: utf-8
# pip install pyexcel
# pip install pyexcel_xlsx

import sys
import re
import os
from pyexcel_xlsx import get_data 
import warnings

warnings.simplefilter("ignore")


def get_ip(fn):
    result = []
    data = get_data(fn)
    fn2 = fn.split('.xlsx')[0] + '.txt'
    for sheet in data:
        result.append('\n\n\n' + sheet + '\n')
        result.extend(strip_ip(str(data[sheet])))
    with open(fn2, 'w', encoding='utf-8') as f:
        f.writelines(result)
    print('{} build!'.format(fn2))


def strip_ip(s):
    patt = r'(\d+\.\d+\.\d+\.\d+/\d+\s)|(\d+\.\d+\.\d+\.\d+)'
    ip_lst = [''.join(i) for i in re.findall(patt, s)]
    result = [i+'\n' for i in ip_lst]
    return result


if __name__ == '__main__':
    files = [i for i in os.listdir('.') if i.endswith('.xlsx') or i.endswith('.xls')]
    for fn in files:
        get_ip(fn)