1. 首先需要安装 python2.7.12 或 python3.5.2，程序已经解决兼容问题
2. python 安装完成后，需要检查环境变量是否配置完成，验证方式如下：
        C:\Users\cmd>python
        Python 3.5.2 (v3.5.2:4def2a2901a5, Jun 25 2016, 22:18:55) [MSC v.1900 64 bit (AMD64)] on win3
        Type "help", "copyright", "credits" or "license" for more information.
        >>> 进入 python shell表示安装并配置成功
3. 程序依赖 pyexcel, beautifulsoup4, lxml 第三方 python 标准库，标准库程序会在联网时自动下载安装，如果失败，请多次尝试
4. 程序 bug，反馈QQ 342737268