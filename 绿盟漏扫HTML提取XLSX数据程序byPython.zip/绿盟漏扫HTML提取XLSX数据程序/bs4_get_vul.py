#!/usr/bin/env python
# encoding: utf-8
# 2016.11.03 15:21:46 with Beautiful Soup4, Python3.5.2 by drop 342737268(QQ)

import re
import os
import sys
import time

COMPAT = False
if '2.7' in sys.version:
    COMPAT = True

def run_cmd(tool):
        os.system('{} install pyexcel'.format(tool))
        os.system('{} install pyexcel_xlsx'.format(tool))
        os.system('{} install beautifulsoup4'.format(tool))
        os.system('{} install lxml'.format(tool))

def install_module():
    path = os.environ.get('PATH')
    if sys.platform == 'linux':
        run_cmd('easy_install')
    elif sys.platform == 'win32':
        if re.search(r'[Pp]ython\d+\\[Ss]cripts', path):
            run_cmd('pip')
            return 0
        path = re.search(r'[CcDdEeFfGg]:\\.+?[Pp]ython\d+\\', path)
        if path:
            os.chdir(path.group() + 'Scripts')
            if not os.path.isfile('./pip.exe'):
                print('Please reinstall python!')
                return 0
            run_cmd('pip')
    return 1

try:
    import pyexcel
    from bs4 import BeautifulSoup
    from bs4 import NavigableString
except:
    install_module()
    import pyexcel
    import pyexcel_xlsx

PATTERN = re.compile(r'(<span\s+class="level_danger_high") |(<span\s+class="level_danger_high")')


class GetVulOfNsfocus(object):
    '''get vulnerability infomation of HTML report export by nsfocus scanner'''
    def __init__(self, xlsx_name='nsfocus_scan_report.xlsx', sheet='IP漏洞表'):
        self.hosts = [i for i in os.listdir('./host') if i.endswith('.html')]
        heading = ['IP地址', '漏洞分级', 'CVE编号', '漏洞', '端口',
                     '协议', '服务', '操作系统', '详细描述', '解决办法', ]
        self.array = [heading]
        self.sheet = sheet
        self.xlsx_name = xlsx_name
        self.run()

    def run(self):
        count = 0
        a = len(self.hosts)
        string = '{:%s}/{} {:16} vuls:{}' % (len(str(a)))
        for host in self.hosts:
            count += 1
            vul_count = self.get_vul('./host/' + host)
            print(string.format(count, a, host[:-5], vul_count))
        self.get_xlsx()

    def get_vul(self, host):
        '''get excel lines of target host'''
        if COMPAT:
            html = open(host).read().decode('utf-8')
        else:
            html = open(host, encoding='utf-8').read()
        if not PATTERN.search(html):
            return 0    # optimize speed 26%
        host_soup = BeautifulSoup(html, 'lxml')
        # ['IP地址', '操作系统']
        host_summary = self.get_summary(host_soup)
        # ['端口', '协议', '服务', '漏洞', '漏洞分级']
        vul_summary = self.get_vul_summary(host_soup)
        # ['详细描述', '解决办法', 'CVE编号']
        detail = self.get_detail(host_soup, vul_summary)
        self.combine_result(host_summary, detail)
        return len(detail)

    def combine_result(self, host_summary, detail):
        for vul_name in detail:
            line = [vul_name]
            line.extend(host_summary)
            line.extend(detail[vul_name])
            if len(line) != 10:
                raise ValueError
            # Oracle 2010年10月更新修复多个Oracle Database安全漏洞, multi-vul-name
            vul, ip, osx, port, proto, serv, level, descri, solu, cve = line
            line = [ip, level, cve, vul, port, proto, serv, osx, descri, solu]
            self.array.append(line)

    def get_summary(self, host_soup):
        ''' host report -> section 1: host summary, return list '''
        result = []
        condition = (u'IP地址', u'操作系统')
        p = host_soup.find('tr', class_='even').parent
        for i in p.contents:
            if type(i) is NavigableString:
                continue
            elif i.th.string in condition:
                result.append(i.td.string)
        if len(result) < 2:
            result.append(None)
        return result

    def get_vul_summary(self, host_soup):
        ''' host report -> section 2.1: vulnerability summary, return dict '''
        result = dict()
        p = host_soup.find('div', id='title2_1')
        if not p:   # security host have no title2_1
            return False
        trs = p.parent.table.tbody.find_all('tr')
        for tr in trs:
            result.update(self.get_vul_port_proto_serv(tr))
        return result

    def get_vul_port_proto_serv(self, tr):
        result = dict()
        level = {'level_danger_high': '高危', 'level_danger_middle': '中危',
                 'level_danger_low': '低危'}
        port, proto, service = [i.string for i in tr.find_all('td')[0: 3]]
        for tag in tr.find_all('span'):
            cls, name = (tag['class'][0], tag.string)
            if cls == 'level_danger_low':
                continue
            result[name] = [port, proto, service, level[cls]]
        return result

    def get_detail(self, host_soup, vul_summary):
        ''' host report -> section 2.2: vulnerability detail, return dict '''
        name_detail_lst = host_soup.find('div', id='vul_detail').table.contents
        for i in name_detail_lst:
            if type(i) is NavigableString:
                continue
            if i.span:
                name = self.get_name(i)
            elif vul_summary.get(name) and len(vul_summary.get(name)) == 4:
                # in case of repeat vulnerability, len() == 4
                lst = self.get_solution(i)
                vul_summary[name].extend(lst)
        return vul_summary

    def get_name(self, i):
        return i.span.string

    def get_solution(self, tag):
        '''['详细描述', '解决办法', 'CVE编号'] '''
        value = []
        tr_lst = tag.table.contents
        for i in tr_lst:
            if type(i) is NavigableString:
                continue
            if i.th.string in (u'详细描述', u'解决办法'):
                val = [i.strip() for i in i.td.strings]
                val = '\n'.join(val).replace('\n*', '*')
                value.append(val)
            elif i.th.string == u'CVE编号':
                value.append(i.td.string)
        if len(value) == 2:
            value.append(None)
        return value

    def get_xlsx(self):
        try:
            pyexcel.save_as(array=self.array,
                            dest_file_name=self.xlsx_name,
                            dest_sheet_name=self.sheet)
        except KeyboardInterrupt as e:
            print(str(e))
            return False
        print('Successful output file: {}'.format(self.xlsx_name))


if __name__ == '__main__':
    t0 = time.time()
    GetVulOfNsfocus()
    print('time used:\t{}s'.format(round(time.time() - t0, 2)))
